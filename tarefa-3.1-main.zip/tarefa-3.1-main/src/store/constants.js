export const STORAGE_ACCESS_TOKEN = "user_token";
export const STORAGE_USER_PROFILE = "user_profile";
export const SEND_EMAIL = "sendEMail";
export const SET_MESSAGE = "setMessage"
