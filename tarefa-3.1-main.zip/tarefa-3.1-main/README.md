# Tarefa 3.1
Mestrado em Engenharia Informática e Tecnologia Web

Programação Web Avançada 2022

Alexandre Carvalho

Project url: https://github.com/Alexandrense/tarefa-3.1

Documentação: https://github.com/Alexandrense/tarefa-3.1/tree/main/documentacao
- Mockups: https://github.com/Alexandrense/tarefa-3.1/tree/main/documentacao/Mockups
- Wireframes: https://github.com/Alexandrense/tarefa-3.1/tree/main/documentacao/Wireframes

# Based on: Animalec
An animals pedagogical app

# Using json-server 
To mock some dummy results
https://github.com/typicode/json-server
